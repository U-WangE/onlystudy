
setTimeout(alert("Welcome!! U-WangE's first site."), 5);