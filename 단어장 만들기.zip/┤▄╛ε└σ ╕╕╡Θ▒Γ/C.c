#include<stdio.h>
#include<stdlib.h>

typedef struct word{
	int num;
	char* english;
	char* mean;
	struct word *next;
}word;

void resetword(word* ap) {
	ap->num = 0;
	ap->english = (char*)calloc(10,sizeof(char));
	ap->mean = (char*)calloc(20,sizeof(char));
	ap->next=NULL;
}

void addword(word *ap, char *newEnglish, char *newMean) {
	word node;
	resetword(&node);
	node.num = ap->num + 1;
	node.english = newEnglish;
	node.mean = newMean;
	ap->next = &node;
}

void question(word *ap) {
	char * newEnglish = (char*)malloc(10*sizeof(char));
	char * newMean = (char*)malloc(20*sizeof(char));
	
	printf("���ܾ� : "); 
	scanf("%s",newEnglish);
	printf("�ǹ� : "); 
	scanf("%s",newMean);
	
	addword(ap, newEnglish, newMean);
}

void main() {
	word a;
	word *ap = &a;
	int choose;
	
	resetword(ap);
	
	while(1) {
		printf("�ܾ����� ����� ���ô�.\n\n");
		printf("1. �� �ܾ�\n2. �ܾ� �����\n3. �ܾ� ����\n\n"); 
		scanf("%d",choose); 
		
		switch(choose) {
			case 1:
				question(ap);
				break;
			case 2:
				break;
			case 3:
				break;
			default :
				printf("�ٽ� �Է��� �ּ���.\n\n");
				printf("------------------------------\n\n");
				break;
		}
	}
}
