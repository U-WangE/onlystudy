function bullet_style(ObjName, type) {
    var obj = document.getElementById(ObjName);
    if(type == 'T') {
        obj.style.listStyle = "url('../style/img/left-bullet.png')";
    } else if(type=='S') {
        obj.style.listStyle = "url('../style/img/square-bullet.png')";
    }
}
