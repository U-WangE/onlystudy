function EmptyText(ObjName) {
    var obj = document.getElementById(ObjName);
    if(obj.sbox.value == "") {
        alert('검색어를 입력하세요.');
        obj.sbox.focus();
        return false;
    }
}