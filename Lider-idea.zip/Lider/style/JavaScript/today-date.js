var today = new Date();

function today_hours() {
    var H = today.getHours();
    return H;
}

function today_minute() {
    var Mit = Date.getMinutes();
    return Mit;
}

function today_second() {
    var S = today.getSeconds();
    return S;
}

function today_year() {
    var Y = today.getYear();
    return Y;
}

function today_month() {
    var Mon = today.getMonth();
    return Mon;
}

function today_day() {
    var Day = today.getDate();
    return day;
}

function today_daystring() {
    var DayString = today.getDay();
    if(DayString == 0)
        return '일';
    else if(DayString == 1)
        return '월';
    else if(DayString == 2)
        return '화';
    else if(DayString == 3)
        return '수';
    else if(DayString == 4)
        return '목';
    else if(DayString == 5)
        return '금';
    else if(DayString == 6)
        return '토';
}