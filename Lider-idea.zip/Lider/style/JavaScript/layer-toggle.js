function layer_toggle(ObjName) {
    var obj = document.getElementById(ObjName);
    if (obj.style.display=='none') obj.style.display = 'block';
    else if (obj.style.display=='block') obj.style.display = 'none';
}
