function layer_toggle(ObjName, num) {
    var obj = document.getElementById(ObjName);
    if (obj.style.display=='none')
        obj.style.display = 'block';
    else if (obj.style.display=='block')
        obj.style.display = 'none';
        
    if(num == 0)
        obj.style.listStyle = "url('../style/img/up-bullet.png')";
    else if(num == 1)
        obj.style.listStyle = "url('../style/img/down-bullet.png')";
}
