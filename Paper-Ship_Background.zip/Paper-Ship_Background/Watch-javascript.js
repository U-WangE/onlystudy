function NowTime() {
    var data = new Date();
    var Hour = addZero(data.getHours());
    var Minute = addZero(data.getMinutes());
    var Second = addZero(data.getSeconds());
    var AmPm = "AM";
    
    if (Hour >= 12) {
        Hour = addZero(Hour - 12);
        AmPm = "PM";
    }

    document.getElementsByName('NAmPm')[0].innerHTML = AmPm;
    document.getElementsByName('NHour')[0].value = Hour;
    document.getElementsByName('NMinute')[0].value = Minute;
    document.getElementsByName('NSecond')[0].value = Second;
    setTimeout("NowTime()",1000); 
}

function addZero(num) {
    var zero = '';
    num = num.toString();
    if (num.length < 2) {
        for (i = 0; i < 2 - num.length; i++) {
            zero += '0';
        } 
    }
    return zero + num;
}

function countOrwatch() {
    if (document.title == "CountDown") {
        location.href = "./Watch.htm";
    } else {
        location.href = "./CountDown.htm";
    }
}