function layer_toggle(ob) {
    var obj = document.getElementById(ob);
    if (obj.style.display=='none') obj.style.display = 'block';
    else if (obj.style.display=='block') obj.style.display = 'none';
}
